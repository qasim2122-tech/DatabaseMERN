import express from 'express';
import routProduct from './routes/routeProduct.js'

const app = express();
app.use('/api' , routeProduct)
const port = 3000;



app.listen(port,()=>{
  console.log('server is running on the ${port}');
});
