import { product } from "../data.js"


 export const getAllProduct= function(req ,res , next) {
    res.send(product)
    }
    export const getProductbyid = function(req ,res , next ) {
        res.send(product)
        }
      export const createNewProduct = function(req ,res , next) {
            res.send(product)
            }
    export  const updateProduct = function(req ,res , next) {
                res.send(product)
                }
   export const deleteProduct = function(req ,res , next) {
                    res.send(product)
                    }

