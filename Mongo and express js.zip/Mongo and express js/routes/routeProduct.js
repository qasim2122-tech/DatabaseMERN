import express from 'express';
import { createNewProduct, deleteProduct, getAllProduct, getProductbyid, updateProduct } from '../Controller/controllerProduct.js';

const router = express.Router();

router.route("/product").get(getAllProduct);
router.route("/product/id").get(getProductbyid);
router.route("/product").post(createNewProduct);
router.route("/product/id").put(updateProduct);
router.route("/product/id").delete(deleteProduct);

export default router;